Barcode Example!
===

This is a simple example of the barcode plugin. To use, add the plugin https://github.com/wildabeast/BarcodeScanner.git via the command line. 

    cordova plugins add https://github.com/wildabeast/BarcodeScanner.git
  
When the application launches, it presents one button. Clicking the button fires the barecode's scan feature. Point the camera at a barcode or a QR code and it will pick up the data and write out the results to the page.
 
The plugin's documentation may be found here: https://github.com/wildabeast/BarcodeScanner