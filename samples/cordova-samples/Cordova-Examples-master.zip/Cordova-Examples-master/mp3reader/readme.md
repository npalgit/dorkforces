MP3, ID3 Example
===

This application demonstrates how to use ID3 parsing with MP3s. Plugins required are:

* cordova-plugin-console
* cordova-plugin-device
* cordova-plugin-file
* cordova-plugin-media
* hu.dpal.phonegap.plugins.SpinnerDialog

