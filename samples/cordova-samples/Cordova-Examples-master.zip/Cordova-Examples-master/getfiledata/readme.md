File Metadata Example
===

This application requests a file so that it can fetch metadata about
the file.

Please add the following plugin:

	cordova plugin add org.apache.cordova.file

When the application launches, it will fetch www/index.html and display
metadata about it in the DOM. It also dumps the object to the console.