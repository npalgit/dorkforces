angular.module('app.controllers', [])
  
.controller('starWarsFilmsCtrl', function($scope) {

})
   
.controller('filmTitleCtrl', function($scope) {

})
 