Simple Video Demo
--

Just demonstrates how to take video using the Media Capture plugin and then render the result in the DOM.

Add this plugin: cordova-plugin-media-capture

