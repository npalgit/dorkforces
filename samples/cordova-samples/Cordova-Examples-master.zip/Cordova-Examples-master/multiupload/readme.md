Multiuploader Demo
---

This demonstrates how to do N uploads and wait for them all to complete. 
I really need a better readme here.

This demo uses the camera and file-transfer plugins.