SMS Composer Example
===

This application demonstrates how to send a SMS message via a plugin.
It will not work on the simulator (although it correctly handles the
error).

Please add the following plugins:

	com.jsmobile.plugins.sms 0.0.1
	org.apache.cordova.dialogs 0.2.11
