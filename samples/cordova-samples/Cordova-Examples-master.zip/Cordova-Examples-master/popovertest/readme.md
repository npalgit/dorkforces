Popover Options Example
===

This example demonstrates how to use popover options with the Camera API.

Please run the following line to add the plugin:

    cordova plugin add org.apache.cordova.camera

Fire up an iOS simulator using the iPad and click the button to see it in action.