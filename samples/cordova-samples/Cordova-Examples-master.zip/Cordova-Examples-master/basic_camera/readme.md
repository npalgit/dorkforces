Basic Camera Example
===

A super simple camera demo. Allows you to take from the camera or library.

    cordova plugin add org.apache.cordova.camera
